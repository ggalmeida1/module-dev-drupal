<?php

namespace Drupal\rsvplist\Controller;

// Missing.
use Drupal\Component\Utility\Html;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;

/**
 * Controller for RSVP List Report
 * {@inheritDoc}
 */
class ReportController extends ControllerBase {

  /**
   * Gets all RSVPs for all nodes.
   *
   * @return array
   */
  protected function load(): array {
    // Added type array.
    $select = Database::getConnection()->select('rsvplist', 'r');
    // Join the users table, so we can get the entry creator's username.
    $select->join('users_field_data', 'u', 'r.uid = u.uid');
    // Join the node table, so we can get the event's name.
    $select->join('node_field_data', 'n', 'r.nid = n.nid');
    // Select these specific fields for the output.
    // Missing.
    $select->addField('r', 'id');
    $select->addField('u', 'name', 'username');
    $select->addField('n', 'title');
    $select->addField('r', 'mail');
    $entries = $select->execute()->fetchAll(\PDO::FETCH_ASSOC);
    return $entries;
  }

  /**
   * Creates the report page.
   *
   * @return array
   *   Render array for report output.
   */
  public function report(): array {
    // Added type array.
    $content = [];
    $content['message'] = [
      '#markup' => $this->t(
          'Below is a list of all Event RSVPs including username,
        email address and the name of the event they will be attending'
      ),
    ];

    // From line 56 to here.
    $rows = [];

    // From line 59 to here.
    foreach ($entries = $this->load() as $entry) {
      // Added parenthesis.
      $obj_html = new Html();
      // Sanitize each entry.
      $rows[] = array_map(
            function ($entry) use ($obj_html) {
                return $obj_html::escape($entry);
            }, $entry
        );
    }

    $headers = [
    // Missing.
      $this->t('ID'),
      $this->t('Name'),
      $this->t('Event'),
      $this->t('Email'),
    ];

    $content['table'] = [
      '#type' => 'table',
      '#header' => $headers,
      '#rows' => $rows,
      '#empty' => $this->t('No entries available.'),
    ];
    // Don't cache this page.
    $content['#cache']['max-age'] = 0;
    return $content;
  }

}
