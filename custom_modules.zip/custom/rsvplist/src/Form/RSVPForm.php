<?php

namespace Drupal\rsvplist\Form;

use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Component\Utility\EmailValidator;
use Drupal\contact\Entity\Message;
use Drupal\contact\MessageInterface;
use Drupal\Core\Session\AccountProxy;
use Drupal\Core\Messenger\MessengerInterface;

/**
 * Provides an RSVP Email form.
 */
class RSVPForm extends FormBase
{

    /**
     * The routeMatch.
     *
     * @var \Drupal\Core\Routing\RouteMatchInterface
     */
    protected $routeMatch;


  /**
   * User.
   *
   * @var \Drupal\Core\Session\AccountProxy
   */
  protected $currentUser;

  /**
   * Messenger
   *
   * @var \Drupal\Core\Messenger\MessengerInterface

   */
  protected $messenger;
  /**
   * Constructor.
   *
   * @inheritDoc
   */
    public function __construct(RouteMatchInterface $route_match, AccountProxy $current_user, MessageInterface $messenger)
    {
        $this->routeMatch = $route_match;
        $this->currentUser = $current_user;
        $this->messenger =  $messenger;
    }

      /**
       * @inheritDoc
       */
      public static function create(ContainerInterface $container)
      {
        return new static(
            $container->get('current_route_match'),
            $container->get('current_user'),
            $container->get('messenger'),
        );
    }

  /**
   * @inheritDoc
   */
    public function getFormId()
    {
        return 'rsvplist_email_form';
    }

  /**
   * @inheritDoc
   */
    public function buildForm(array $form, FormStateInterface $form_state) {
        $node = $this->routeMatch->getParameter('node');
        if (isset($node)) {
            $nid = $node->id();
        }
        $form['email'] = [
          '#title' => $this->t('Email Address'),
          '#type' => 'textfield',
          '#size' => 25,
          '#description' => $this->t("We'll send updates to the email address you provide"),
          '#required' => true,
        ];
        $form['submit'] = [
          '#type' => 'submit',
          '#value' => $this->t('RSVP'),
        ];
        $form['nid'] = [
          '#type' => 'hidden',
          '#value' => $nid,
        ];
        return $form;
      }

      /**
       * @inheritDoc
       */
    public function validateForm(array &$form, FormStateInterface $form_state) {
        $value = $form_state->getValue('email');
        $validator = new EmailValidator();
        if ($value == !$validator->isValid($value)) {
            $form_state->setErrorByName(
                'email', $this->t(
                    'The email address %mail is not valid.', [
                      '%mail' => $value,
                    ]
                )
            );
            return;
        }
    $node = $this->routeMatch->getParameter('node');
    // Check if email already is set for this node.
    $select = Database::getConnection()->select('rsvplist', 'r');
    $select->fields('r', ['nid']);
    $select->condition('nid', $node->id());
    $select->condition('mail', $value);
    $results = $select->execute();
    if (!empty($results->fetchCol())) {
      // We found a row with this nid and email.
      $form_state->setErrorByName('email', $this->t('The address %mail is already subscribed to this list.', ['%mail' => $value]));
    }
  }

  /**
   * @inheritDoc
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    Database::getConnection()->insert('rsvplist')->fields(
          [
            'mail' => $form_state->getValue('email'),
            'nid' => $form_state->getValue('nid'),
            'uid' => $this->currentUser()->id(),
            'created' => time(),
          ]
      )
      ->execute();
        $this->messenger()->addMessage(
            $this->t(
                'Thank you for your RSVP, you are on the list for the event.'
            )
        );
      }

}
