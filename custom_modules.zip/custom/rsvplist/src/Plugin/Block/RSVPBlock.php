<?php

/**
 * PHP 8.0.10
 *
 * @category Description
 * @package  Category
 * @license  MIT https://choosealicense.com/licenses/mit/
 * @link     http://url.com
 */
namespace Drupal\rsvplist\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Form\FormBuilderInterface;


/**
 * Provides an 'RSVP' List Block.
 *
 * @Block(
 *  id = "rsvp_block",
 *  admin_label = @Translation("RSVP Block"),
 * )
 */
class RSVPBlock extends BlockBase
{

      /**
       * The routeMatch.
       *
       * @var \Drupal\Core\Routing\RouteMatchInterface
       */
    protected $routeMatch;

      /**
       * The FormBuilder.
       *
       * @var \Drupal\Core\Form\FormBuilderInterface
       */
    protected $formBuilder;


    /**
     * {@inheritDoc}
     */
    public function __construct(RouteMatchInterface $route_match, FormBuilderInterface $form_builder)
    {
        $this->routeMatch = $route_match;
        $this->formBuilder = $form_builder;
    }
    /**
     * {@inheritDoc}
     */
    public function build()
    {
        return $this->formBuilder->getForm('Drupal\rsvplist\Form\RSVPForm');
    }

    /**
     * Undocumented function.
     *
     * {@inheritDoc}
     */
    public function blockAccess(AccountInterface $account)
    {
        /**
         * @var \Drupal\node\Entity\Node $node
         *
         */
        $node = $this->routeMatch->getParameter('node');
        $nid = $node->nid->value;

        /**
         *  @var \Drupal\rsvplist\EnablerService $enabler
         *
        */
        $enabler = \Drupal::service('rsvplist.enabler');
        if (is_numeric($nid)) {
            if ($enabler->isEnabled($node)) {
                return AccessResult::allowedIfHasPermission(
                    $account, 'view rsvplist'
                );
            }
        }
        return AccessResult::forbidden();
    }

}
